# College ID Fine Management System - Tkinter GUI Version

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import os
import json
import shutil
import qrcode
import random
import string
from datetime import datetime, timedelta
import re
from pathlib import Path
import platform

# Configuration
DB_FILE = "data.json"
QR_DIR = "qr_codes"
RECEIPT_DIR = "receipts"
UPLOAD_DIR = "uploads"
ADMIN_PASSWORD = "admin123"
TOKEN_TTL_MINUTES = 10
FINE_AMOUNTS = {1: 50, 2: 100, 3: 150}
MAX_ATTEMPTS_PER_MONTH = 3

# Create directories
for directory in [QR_DIR, RECEIPT_DIR, UPLOAD_DIR]:
    Path(directory).mkdir(exist_ok=True)

# Utility Functions
def load_db():
    if not os.path.exists(DB_FILE):
        return {}
    try:
        with open(DB_FILE, "r", encoding="utf-8") as f:
            content = f.read().strip()
            return json.loads(content) if content else {}
    except:
        return {}

def save_db(db):
    try:
        with open(DB_FILE, "w", encoding="utf-8") as f:
            json.dump(db, f, indent=2, ensure_ascii=False)
        return True
    except:
        return False

def validate_roll_no(roll):
    if not roll:
        return False, "Roll number required"
    roll = roll.strip().upper()
    if not re.match(r'^[FST]\d{3}$', roll):
        return False, "Invalid format! Use F089, S102, or T145"
    return True, "Valid"

def validate_email(email):
    if not email:
        return False
    return re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email) is not None

def validate_contact(contact):
    if not contact:
        return False
    return re.match(r'^\+?\d{7,15}$', contact) is not None

def get_year_from_roll(roll):
    mapping = {'F': 'First Year', 'S': 'Second Year', 'T': 'Third Year'}
    return mapping.get(roll[0].upper(), 'Unknown')

def gen_token(n=10):
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=n))

def attempts_this_month(user):
    if not user:
        return 0
    now = datetime.now()
    y, m = now.year, now.month
    cnt = 0
    for a in user.get("attempts", []):
        try:
            ts = datetime.fromisoformat(a.get("timestamp"))
            if ts.year == y and ts.month == m:
                cnt += 1
        except:
            continue
    return cnt

def is_token_expired(expires_at_str):
    if not expires_at_str:
        return True
    try:
        exp = datetime.fromisoformat(expires_at_str)
        return datetime.now() > exp
    except:
        return True

def open_file(filepath):
    try:
        if platform.system() == 'Windows':
            os.startfile(filepath)
        elif platform.system() == 'Darwin':
            os.system(f'open "{filepath}"')
        else:
            os.system(f'xdg-open "{filepath}"')
        return True
    except:
        return False

# Main Application
class CollegeFineApp:
    def __init__(self, root):
        self.root = root
        self.root.title("College ID Fine Management System")
        self.root.geometry("1000x750")
        self.root.configure(bg='#f5f5f5')
        
        # Colors
        self.primary_color = "#2c3e50"
        self.accent_color = "#3498db"
        self.success_color = "#27ae60"
        self.danger_color = "#e74c3c"
        self.bg_color = "#f5f5f5"
        
        # Center window
        self.center_window()
        
        self.create_main_menu()
    
    def center_window(self):
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
    
    def clear_window(self):
        for widget in self.root.winfo_children():
            widget.destroy()
    
    def create_header(self, subtitle=""):
        header_frame = tk.Frame(self.root, bg=self.primary_color, height=100)
        header_frame.pack(fill=tk.X)
        header_frame.pack_propagate(False)
        
        tk.Label(
            header_frame,
            text="🎓 College ID Fine Management System",
            font=("Segoe UI", 20, "bold"),
            bg=self.primary_color,
            fg="white"
        ).pack(pady=(15, 5))
        
        if subtitle:
            tk.Label(
                header_frame,
                text=subtitle,
                font=("Segoe UI", 12),
                bg=self.primary_color,
                fg="#ecf0f1"
            ).pack()
    
    def create_button(self, parent, text, command, bg_color=None):
        if bg_color is None:
            bg_color = self.accent_color
        
        btn = tk.Button(
            parent,
            text=text,
            font=("Segoe UI", 12, "bold"),
            bg=bg_color,
            fg="white",
            width=22,
            height=2,
            relief=tk.FLAT,
            cursor="hand2",
            activebackground=self.primary_color,
            activeforeground="white",
            command=command
        )
        return btn
    
    def create_main_menu(self):
        self.clear_window()
        self.create_header("Digital Payment System")
        
        # Main container
        main_frame = tk.Frame(self.root, bg=self.bg_color)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=50, pady=40)
        
        # Welcome message
        tk.Label(
            main_frame,
            text="Welcome! Select an Option",
            font=("Segoe UI", 18, "bold"),
            bg=self.bg_color,
            fg=self.primary_color
        ).pack(pady=(0, 30))
        
        # Buttons container
        btn_container = tk.Frame(main_frame, bg=self.bg_color)
        btn_container.pack(expand=True)
        
        buttons_data = [
            ("📝  Register Student", self.register_screen, self.accent_color),
            ("💳  Generate QR Code", self.generate_qr_screen, self.accent_color),
            ("✅  Confirm Payment", self.confirm_payment_screen, self.success_color),
            ("⚙️  Admin Panel", self.admin_login_screen, self.primary_color),
            ("🚪  Exit Application", self.root.quit, self.danger_color)
        ]
        
        for text, cmd, color in buttons_data:
            btn = self.create_button(btn_container, text, cmd, color)
            btn.pack(pady=8)
        
        # Footer info
        info_frame = tk.Frame(main_frame, bg="#ecf0f1", relief=tk.FLAT, bd=1)
        info_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=(30, 0))
        
        tk.Label(
            info_frame,
            text="ℹ️  Token valid for 10 minutes | Max 3 attempts per month",
            font=("Segoe UI", 9),
            bg="#ecf0f1",
            fg="#7f8c8d"
        ).pack(pady=10)
    
    def register_screen(self):
        self.clear_window()
        self.create_header("Register New Student")
        
        # Scrollable canvas
        canvas = tk.Canvas(self.root, bg="white", highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.root, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="white")
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw", width=1000)
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Content
        content = tk.Frame(scrollable_frame, bg="white")
        content.pack(fill=tk.BOTH, expand=True, padx=80, pady=30)
        
        # Info card
        info_card = tk.Frame(content, bg="#e8f4f8", relief=tk.SOLID, bd=1)
        info_card.pack(fill=tk.X, pady=(0, 25))
        
        tk.Label(
            info_card,
            text="📋 Roll Number Format: F089 / S102 / T145",
            font=("Segoe UI", 11, "bold"),
            bg="#e8f4f8",
            fg=self.primary_color
        ).pack(pady=12)
        
        # Form fields
        fields = [
            ("Roll Number", "roll", "🎓"),
            ("Full Name", "name", "👤"),
            ("Email Address", "email", "📧"),
            ("Contact Number", "contact", "📱")
        ]
        
        self.register_entries = {}
        
        for label, field, emoji in fields:
            frame = tk.Frame(content, bg="white")
            frame.pack(fill=tk.X, pady=12)
            
            tk.Label(
                frame,
                text=f"{emoji}  {label} *",
                font=("Segoe UI", 11, "bold"),
                bg="white",
                fg=self.primary_color,
                anchor="w"
            ).pack(anchor="w", pady=(0, 5))
            
            entry = tk.Entry(
                frame,
                font=("Segoe UI", 12),
                relief=tk.SOLID,
                bd=1,
                highlightthickness=2,
                highlightcolor=self.accent_color
            )
            entry.pack(fill=tk.X, ipady=10)
            self.register_entries[field] = entry
        
        # College ID upload
        id_frame = tk.Frame(content, bg="white")
        id_frame.pack(fill=tk.X, pady=12)
        
        tk.Label(
            id_frame,
            text="🆔  College ID Card (Optional)",
            font=("Segoe UI", 11, "bold"),
            bg="white",
            fg=self.primary_color,
            anchor="w"
        ).pack(anchor="w", pady=(0, 5))
        
        self.college_id_path = tk.StringVar()
        
        upload_container = tk.Frame(id_frame, bg="white")
        upload_container.pack(fill=tk.X)
        
        tk.Entry(
            upload_container,
            textvariable=self.college_id_path,
            font=("Segoe UI", 10),
            state="readonly",
            relief=tk.SOLID,
            bd=1
        ).pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=8)
        
        tk.Button(
            upload_container,
            text="Browse",
            font=("Segoe UI", 10, "bold"),
            bg="#95a5a6",
            fg="white",
            relief=tk.FLAT,
            cursor="hand2",
            command=self.browse_college_id
        ).pack(side=tk.LEFT, padx=(10, 0), ipady=7, ipadx=15)
        
        # Action buttons
        btn_frame = tk.Frame(content, bg="white")
        btn_frame.pack(pady=30)
        
        self.create_button(
            btn_frame,
            "✅  Register Student",
            self.register_student,
            self.success_color
        ).pack(side=tk.LEFT, padx=8)
        
        self.create_button(
            btn_frame,
            "🏠  Back to Menu",
            self.create_main_menu,
            self.primary_color
        ).pack(side=tk.LEFT, padx=8)
        
        # Bind mouse wheel
        canvas.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(int(-1*(e.delta/120)), "units"))
    
    def browse_college_id(self):
        filename = filedialog.askopenfilename(
            title="Select College ID Card",
            filetypes=[("Image files", "*.jpg *.jpeg *.png"), ("All files", "*.*")]
        )
        if filename:
            self.college_id_path.set(filename)
    
    def register_student(self):
        db = load_db()
        
        roll = self.register_entries['roll'].get().strip().upper()
        name = self.register_entries['name'].get().strip()
        email = self.register_entries['email'].get().strip().lower()
        contact = self.register_entries['contact'].get().strip()
        
        # Validation
        is_valid, msg = validate_roll_no(roll)
        if not is_valid:
            messagebox.showerror("Validation Error", msg)
            return
        
        if roll in db:
            messagebox.showerror("Error", f"Roll number '{roll}' is already registered!")
            return
        
        if not name:
            messagebox.showerror("Validation Error", "Name is required")
            return
        
        if not validate_email(email):
            messagebox.showerror("Validation Error", "Please enter a valid email address")
            return
        
        if not validate_contact(contact):
            messagebox.showerror("Validation Error", "Contact number must be 7-15 digits")
            return
        
        # Handle file upload
        dest = None
        id_path = self.college_id_path.get()
        if id_path and os.path.exists(id_path):
            try:
                filename = f"{roll}_{os.path.basename(id_path)}"
                dest = os.path.join(UPLOAD_DIR, filename)
                shutil.copyfile(id_path, dest)
            except Exception as e:
                messagebox.showwarning("Upload Warning", f"File upload failed: {e}")
        
        # Save to database
        db[roll] = {
            "roll": roll,
            "name": name,
            "email": email,
            "contact": contact,
            "year": get_year_from_roll(roll),
            "college_id": dest,
            "registered_at": datetime.now().isoformat(),
            "attempts": []
        }
        
        if save_db(db):
            messagebox.showinfo(
                "Success",
                f"✅ Registration Successful!\n\n"
                f"Student: {name}\n"
                f"Roll Number: {roll}\n"
                f"Year: {get_year_from_roll(roll)}\n\n"
                f"You can now generate QR code for payment."
            )
            self.create_main_menu()
        else:
            messagebox.showerror("Error", "Failed to save registration. Please try again.")
    
    def generate_qr_screen(self):
        self.clear_window()
        self.create_header("Generate QR Code for Payment")
        
        content = tk.Frame(self.root, bg="white")
        content.pack(fill=tk.BOTH, expand=True, padx=100, pady=50)
        
        tk.Label(
            content,
            text="Enter Student Roll Number",
            font=("Segoe UI", 16, "bold"),
            bg="white",
            fg=self.primary_color
        ).pack(pady=(0, 30))
        
        # Input card
        input_card = tk.Frame(content, bg="#f8f9fa", relief=tk.SOLID, bd=1)
        input_card.pack(fill=tk.X, pady=20)
        
        tk.Label(
            input_card,
            text="🎓  Roll Number",
            font=("Segoe UI", 12, "bold"),
            bg="#f8f9fa",
            fg=self.primary_color
        ).pack(anchor="w", padx=20, pady=(20, 5))
        
        self.qr_roll_entry = tk.Entry(
            input_card,
            font=("Segoe UI", 14),
            relief=tk.SOLID,
            bd=1,
            highlightthickness=2,
            highlightcolor=self.accent_color
        )
        self.qr_roll_entry.pack(fill=tk.X, padx=20, pady=(0, 20), ipady=12)
        self.qr_roll_entry.focus()
        
        # Buttons
        btn_frame = tk.Frame(content, bg="white")
        btn_frame.pack(pady=30)
        
        self.create_button(
            btn_frame,
            "🔄  Generate QR Code",
            self.generate_qr,
            self.accent_color
        ).pack(side=tk.LEFT, padx=8)
        
        self.create_button(
            btn_frame,
            "🏠  Back to Menu",
            self.create_main_menu,
            self.primary_color
        ).pack(side=tk.LEFT, padx=8)
    
    def generate_qr(self):
        db = load_db()
        roll = self.qr_roll_entry.get().strip().upper()
        
        if not roll:
            messagebox.showwarning("Input Required", "Please enter roll number")
            return
        
        user = db.get(roll)
        if not user:
            messagebox.showerror("Not Found", "Student not found. Please register first!")
            return
        
        cnt = attempts_this_month(user)
        if cnt >= MAX_ATTEMPTS_PER_MONTH:
            messagebox.showerror(
                "Limit Reached",
                f"Maximum {MAX_ATTEMPTS_PER_MONTH} attempts reached this month.\n\n"
                f"Attempts made: {cnt}"
            )
            return
        
        fine = FINE_AMOUNTS.get(cnt + 1)
        if not fine:
            messagebox.showerror("Error", "No further attempts allowed")
            return
        
        # Confirm
        confirm = messagebox.askyesno(
            "Confirm Generation",
            f"Student: {user['name']}\n"
            f"Year: {user['year']}\n"
            f"Attempt: #{cnt+1} this month\n"
            f"Fine Amount: Rs.{fine}\n\n"
            f"Generate QR Code?"
        )
        
        if not confirm:
            return
        
        # Generate token
        token = gen_token(10)
        expires_at = (datetime.now() + timedelta(minutes=TOKEN_TTL_MINUTES)).isoformat()
        
        attempt = {
            "timestamp": datetime.now().isoformat(),
            "fine": fine,
            "status": "pending",
            "token": token,
            "expires_at": expires_at,
            "payment_id": None,
            "proof": None,
            "paid_at": None
        }
        
        user["attempts"].append(attempt)
        
        if not save_db(db):
            messagebox.showerror("Error", "Failed to save attempt")
            return
        
        # Generate QR
        qr_payload = f"ROLL:{roll}|AMT:{fine}|TOKEN:{token}|UPI:college@upi"
        qr_filename = f"payment_{roll}_{int(datetime.now().timestamp())}.png"
        qr_file = os.path.join(QR_DIR, qr_filename)
        
        try:
            qr_img = qrcode.make(qr_payload)
            qr_img.save(qr_file)
            
            messagebox.showinfo(
                "QR Code Generated!",
                f"✅ QR Code Generated Successfully!\n\n"
                f"🔑 TOKEN: {token}\n\n"
                f"⏰ Valid for {TOKEN_TTL_MINUTES} minutes\n"
                f"💰 Amount: Rs.{fine}\n\n"
                f"═══════════════════════\n"
                f"Instructions:\n"
                f"1. Scan QR code with UPI app\n"
                f"2. Complete the payment\n"
                f"3. Use 'Confirm Payment' option\n"
                f"4. Enter this TOKEN to verify\n\n"
                f"QR Code will open now..."
            )
            
            open_file(qr_file)
            self.create_main_menu()
            
        except Exception as e:
            user["attempts"].pop()
            save_db(db)
            messagebox.showerror("Error", f"QR generation failed: {e}")
    
    def confirm_payment_screen(self):
        self.clear_window()
        self.create_header("Confirm Payment")
        
        content = tk.Frame(self.root, bg="white")
        content.pack(fill=tk.BOTH, expand=True, padx=80, pady=40)
        
        tk.Label(
            content,
            text="Verify & Confirm Payment",
            font=("Segoe UI", 16, "bold"),
            bg="white",
            fg=self.primary_color
        ).pack(pady=(0, 30))
        
        # Form card
        form_card = tk.Frame(content, bg="#f8f9fa", relief=tk.SOLID, bd=1)
        form_card.pack(fill=tk.X, pady=20)
        form_card.pack_propagate(False)
        form_card.configure(height=350)
        
        form_content = tk.Frame(form_card, bg="#f8f9fa")
        form_content.pack(fill=tk.BOTH, expand=True, padx=30, pady=30)
        
        # Fields
        fields = [
            ("Roll Number", "roll", "🎓"),
            ("Payment Token", "token", "🔑"),
            ("Transaction ID (Optional)", "proof", "📝")
        ]
        
        self.confirm_entries = {}
        
        for label, field, emoji in fields:
            tk.Label(
                form_content,
                text=f"{emoji}  {label}",
                font=("Segoe UI", 11, "bold"),
                bg="#f8f9fa",
                fg=self.primary_color,
                anchor="w"
            ).pack(anchor="w", pady=(10, 5))
            
            entry = tk.Entry(
                form_content,
                font=("Segoe UI", 12),
                relief=tk.SOLID,
                bd=1,
                highlightthickness=2,
                highlightcolor=self.accent_color
            )
            entry.pack(fill=tk.X, ipady=10, pady=(0, 15))
            self.confirm_entries[field] = entry
        
        # Buttons
        btn_frame = tk.Frame(content, bg="white")
        btn_frame.pack(pady=30)
        
        self.create_button(
            btn_frame,
            "✅  Confirm Payment",
            self.confirm_payment,
            self.success_color
        ).pack(side=tk.LEFT, padx=8)
        
        self.create_button(
            btn_frame,
            "🏠  Back to Menu",
            self.create_main_menu,
            self.primary_color
        ).pack(side=tk.LEFT, padx=8)
    
    def confirm_payment(self):
        db = load_db()
        
        roll = self.confirm_entries['roll'].get().strip().upper()
        token = self.confirm_entries['token'].get().strip().upper()
        proof = self.confirm_entries['proof'].get().strip()
        
        if not roll or not token:
            messagebox.showwarning("Input Required", "Please enter roll number and token")
            return
        
        user = db.get(roll)
        if not user:
            messagebox.showerror("Not Found", "Student not found")
            return
        
        # Find pending attempt
        pending = None
        for a in reversed(user.get("attempts", [])):
            if a.get("status") == "pending":
                pending = a
                break
        
        if not pending:
            messagebox.showerror("Error", "No pending payment attempt found")
            return
        
        # Check expiry
        if is_token_expired(pending.get("expires_at")):
            pending["status"] = "expired"
            save_db(db)
            messagebox.showerror("Token Expired", "Token has expired! Please generate a new QR code.")
            return
        
        # Verify token
        if token != pending.get("token"):
            messagebox.showerror("Invalid Token", "Token does not match! Please check and try again.")
            return
        
        # Mark as paid
        payment_id = "PAY" + str(random.randint(100000, 999999))
        pending["status"] = "paid"
        pending["payment_id"] = payment_id
        pending["paid_at"] = datetime.now().isoformat()
        if proof:
            pending["proof"] = proof
        
        if not save_db(db):
            messagebox.showerror("Error", "Failed to save payment confirmation")
            return
        
        # Generate receipt
        receipt_filename = f"receipt_{roll}_{int(datetime.now().timestamp())}.txt"
        receipt_file = os.path.join(RECEIPT_DIR, receipt_filename)
        
        try:
            with open(receipt_file, "w", encoding="utf-8") as f:
                f.write("="*60 + "\n")
                f.write("      COLLEGE ID FINE PAYMENT RECEIPT\n")
                f.write("="*60 + "\n\n")
                f.write(f"Receipt Number : {payment_id}\n")
                f.write(f"Date & Time    : {datetime.now().strftime('%d-%m-%Y %I:%M %p')}\n\n")
                f.write("-"*60 + "\n")
                f.write("STUDENT DETAILS:\n")
                f.write("-"*60 + "\n")
                f.write(f"Name           : {user.get('name')}\n")
                f.write(f"Roll Number    : {user.get('roll')}\n")
                f.write(f"Academic Year  : {user.get('year')}\n")
                f.write(f"Email          : {user.get('email', 'N/A')}\n")
                f.write(f"Contact        : {user.get('contact', 'N/A')}\n\n")
                f.write("-"*60 + "\n")
                f.write("PAYMENT DETAILS:\n")
                f.write("-"*60 + "\n")
                f.write(f"Fine Amount    : Rs.{pending.get('fine')}\n")
                f.write(f"Payment Status : PAID\n")
                f.write(f"Token Used     : {pending.get('token')}\n")
                if proof:
                    f.write(f"Transaction ID : {proof}\n")
                f.write("\n" + "="*60 + "\n")
                f.write("PAYMENT SUCCESSFUL\n")
                f.write("Thank you!\n")
                f.write("="*60 + "\n")
            
            messagebox.showinfo(
                "Payment Confirmed!",
                f"🎉 Payment Successful!\n\n"
                f"═══════════════════════\n"
                f"💳 Payment ID: {payment_id}\n"
                f"👤 Student: {user['name']}\n"
                f"💰 Amount: Rs.{pending['fine']}\n"
                f"═══════════════════════\n\n"
                f"📄 Receipt has been generated!\n\n"
                f"Receipt will open now..."
            )
            
            open_file(receipt_file)
            self.create_main_menu()
            
        except Exception as e:
            messagebox.showinfo(
                "Payment Confirmed",
                f"✅ Payment confirmed successfully!\n\n"
                f"💳 Payment ID: {payment_id}\n\n"
                f"Note: Receipt generation error: {e}"
            )
            self.create_main_menu()
    
    def admin_login_screen(self):
        self.clear_window()
        self.create_header("Admin Access")
        
        content = tk.Frame(self.root, bg="white")
        content.pack(fill=tk.BOTH, expand=True, padx=150, pady=80)
        
        tk.Label(
            content,
            text="🔐 Admin Login",
            font=("Segoe UI", 18, "bold"),
            bg="white",
            fg=self.primary_color
        ).pack(pady=(0, 40))
        
        # Login card
        login_card = tk.Frame(content, bg="#f8f9fa", relief=tk.SOLID, bd=1)
        login_card.pack(fill=tk.X)
        
        tk.Label(
            login_card,
            text="🔑 Password",
            font=("Segoe UI", 12, "bold"),
            bg="#f8f9fa",
            fg=self.primary_color
        ).pack(anchor="w", padx=30, pady=(30, 10))
        
        self.admin_password_entry = tk.Entry(
            login_card,
            font=("Segoe UI", 14),
            show="●",
            relief=tk.SOLID,
            bd=1,
            highlightthickness=2,
            highlightcolor=self.accent_color
        )
        self.admin_password_entry.pack(fill=tk.X, padx=30, pady=(0, 20), ipady=12)
        self.admin_password_entry.focus()
        
        tk.Label(
            login_card,
            text="Default: admin123",
            font=("Segoe UI", 9),
            bg="#f8f9fa",
            fg="#95a5a6"
        ).pack(pady=(0, 30))
        
        # Buttons
        btn_frame = tk.Frame(content, bg="white")
        btn_frame.pack(pady=30)
        
        self.create_button(
            btn_frame,
            "🔓  Login",
            self.admin_login,
            self.accent_color
        ).pack(side=tk.LEFT, padx=8)
        
        self.create_button(
            btn_frame,
            "🏠  Back",
            self.create_main_menu,
            self.primary_color
        ).pack(side=tk.LEFT, padx=8)
        
        # Bind Enter key
        self.admin_password_entry.bind('<Return>', lambda e: self.admin_login())
    
    def admin_login(self):
        password = self.admin_password_entry.get()
        if password == ADMIN_PASSWORD:
            self.admin_panel()
        else:
            messagebox.showerror("Access Denied", "Invalid password!")
            self.admin_password_entry.delete(0, tk.END)
            self.admin_password_entry.focus()
    
    def admin_panel(self):
        self.clear_window()
        self.create_header("Admin Dashboard")
        
        # Create notebook for tabs
        style = ttk.Style()
        style.configure('TNotebook.Tab', font=('Segoe UI', 11, 'bold'), padding=[20, 10])
        
        notebook = ttk.Notebook(self.root)
        notebook.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Statistics Tab
        stats_frame = tk.Frame(notebook, bg="white")
        notebook.add(stats_frame, text="📊 Statistics")
        self.show_statistics(stats_frame)
        
        # Users Tab
        users_frame = tk.Frame(notebook, bg="white")
        notebook.add(users_frame, text="👥 All Users")
        self.show_all_users(users_frame)
        
        # Pending Tab
        pending_frame = tk.Frame(notebook, bg="white")
        notebook.add(pending_frame, text="⏳ Pending Payments")
        self.show_pending(pending_frame)
        
        # Back button
        self.create_button(
            self.root,
            "🏠  Back to Menu",
            self.create_main_menu,
            self.primary_color
        ).pack(pady=15)
    
    def show_statistics(self, parent):
        db = load_db()
        
        total = len(db)
        attempts_count = sum(len(u.get("attempts", [])) for u in db.values())
        paid = sum(1 for u in db.values() for a in u.get("attempts", []) if a.get("status") == "paid")
        pending = sum(1 for u in db.values() for a in u.get("attempts", []) if a.get("status") == "pending")
        revenue = sum(a.get('fine', 0) for u in db.values() for a in u.get("attempts", []) if a.get("status") == "paid")
        
        # Header
        tk.Label(
            parent,
            text="System Overview",
            font=("Segoe UI", 16, "bold"),
            bg="white",
            fg=self.primary_color
        ).pack(pady=20)
        
        # Stats container
        container = tk.Frame(parent, bg="white")
        container.pack(fill=tk.BOTH, expand=True, padx=40, pady=20)
        
        stats = [
            ("Total Students", total, "#3498db", "👥"),
            ("Total Attempts", attempts_count, "#9b59b6", "📊"),
            ("Paid Attempts", paid, "#27ae60", "✅"),
            ("Pending Payments", pending, "#f39c12", "⏳"),
            ("Total Revenue", f"Rs.{revenue}", "#e74c3c", "💰")
        ]
        
        row, col = 0, 0
        for label, value, color, emoji in stats:
            card = tk.Frame(container, bg=color, relief=tk.RAISED, bd=3)
            card.grid(row=row, column=col, padx=15, pady=15, sticky="nsew", ipadx=20, ipady=20)
            
            tk.Label(
                card,
                text=emoji,
                font=("Segoe UI", 32),
                bg=color,
                fg="white"
            ).pack(pady=(10, 5))
            
            tk.Label(
                card,
                text=str(value),
                font=("Segoe UI", 28, "bold"),
                bg=color,
                fg="white"
            ).pack()
            
            tk.Label(
                card,
                text=label,
                font=("Segoe UI", 11, "bold"),
                bg=color,
                fg="white"
            ).pack(pady=(5, 10))
            
            col += 1
            if col > 2:
                col = 0
                row += 1
        
        for i in range(3):
            container.columnconfigure(i, weight=1)
    
    def show_all_users(self, parent):
        db = load_db()
        
        # Header
        header_frame = tk.Frame(parent, bg="white")
        header_frame.pack(fill=tk.X, padx=20, pady=20)
        
        tk.Label(
            header_frame,
            text="Registered Students",
            font=("Segoe UI", 16, "bold"),
            bg="white",
            fg=self.primary_color
        ).pack(side=tk.LEFT)
        
        tk.Label(
            header_frame,
            text=f"Total: {len(db)}",
            font=("Segoe UI", 12),
            bg="white",
            fg="#7f8c8d"
        ).pack(side=tk.RIGHT)
        
        # Scrollable frame
        canvas = tk.Canvas(parent, bg="white", highlightthickness=0)
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="white")
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True, padx=20)
        scrollbar.pack(side="right", fill="y")
        
        if not db:
            tk.Label(
                scrollable_frame,
                text="No students registered yet",
                font=("Segoe UI", 14),
                bg="white",
                fg="#95a5a6"
            ).pack(pady=50)
            return
        
        for roll, user in sorted(db.items()):
            card = tk.Frame(scrollable_frame, bg="#ecf0f1", relief=tk.SOLID, bd=1)
            card.pack(fill=tk.X, padx=10, pady=8)
            
            # Header
            card_header = tk.Frame(card, bg=self.accent_color)
            card_header.pack(fill=tk.X)
            
            tk.Label(
                card_header,
                text=f"🎓 {roll} - {user.get('name')}",
                font=("Segoe UI", 12, "bold"),
                bg=self.accent_color,
                fg="white"
            ).pack(side=tk.LEFT, padx=15, pady=10)
            
            tk.Label(
                card_header,
                text=user.get('year'),
                font=("Segoe UI", 10, "bold"),
                bg="white",
                fg=self.accent_color,
                padx=10,
                pady=2
            ).pack(side=tk.RIGHT, padx=15)
            
            # Details
            details_frame = tk.Frame(card, bg="#ecf0f1")
            details_frame.pack(fill=tk.X, padx=15, pady=12)
            
            info_text = f"📧 {user.get('email')}  |  📱 {user.get('contact')}  |  📊 Attempts: {attempts_this_month(user)}/{len(user.get('attempts', []))}"
            
            tk.Label(
                details_frame,
                text=info_text,
                font=("Segoe UI", 10),
                bg="#ecf0f1",
                fg="#2c3e50"
            ).pack(anchor="w")
        
        canvas.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(int(-1*(e.delta/120)), "units"))
    
    def show_pending(self, parent):
        db = load_db()
        
        # Header
        tk.Label(
            parent,
            text="Pending Payment Attempts",
            font=("Segoe UI", 16, "bold"),
            bg="white",
            fg=self.primary_color
        ).pack(pady=20)
        
        # Scrollable frame
        canvas = tk.Canvas(parent, bg="white", highlightthickness=0)
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="white")
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True, padx=20)
        scrollbar.pack(side="right", fill="y")
        
        found = False
        for roll, user in sorted(db.items()):
            for a in user.get("attempts", []):
                if a.get("status") == "pending":
                    found = True
                    expired = is_token_expired(a.get("expires_at"))
                    
                    card_color = "#fff3cd" if not expired else "#f8d7da"
                    status_emoji = "⏰" if not expired else "❌"
                    status_text = "ACTIVE" if not expired else "EXPIRED"
                    status_color = "#856404" if not expired else "#721c24"
                    
                    card = tk.Frame(scrollable_frame, bg=card_color, relief=tk.SOLID, bd=2)
                    card.pack(fill=tk.X, padx=10, pady=8)
                    
                    # Status badge
                    badge_frame = tk.Frame(card, bg=card_color)
                    badge_frame.pack(fill=tk.X, padx=15, pady=(10, 5))
                    
                    tk.Label(
                        badge_frame,
                        text=f"{status_emoji} {status_text}",
                        font=("Segoe UI", 10, "bold"),
                        bg=status_color,
                        fg="white",
                        padx=10,
                        pady=3
                    ).pack(side=tk.LEFT)
                    
                    # Details
                    details = tk.Frame(card, bg=card_color)
                    details.pack(fill=tk.X, padx=15, pady=10)
                    
                    tk.Label(
                        details,
                        text=f"🎓 {roll} - {user.get('name')}",
                        font=("Segoe UI", 12, "bold"),
                        bg=card_color,
                        fg="#2c3e50"
                    ).pack(anchor="w", pady=2)
                    
                    tk.Label(
                        details,
                        text=f"💰 Fine: Rs.{a.get('fine')}",
                        font=("Segoe UI", 10),
                        bg=card_color,
                        fg="#2c3e50"
                    ).pack(anchor="w", pady=2)
                    
                    # Token display
                    token_frame = tk.Frame(details, bg="white", relief=tk.SOLID, bd=1)
                    token_frame.pack(fill=tk.X, pady=5)
                    
                    tk.Label(
                        token_frame,
                        text=f"🔑 TOKEN: {a.get('token')}",
                        font=("Courier", 11, "bold"),
                        bg="white",
                        fg=self.accent_color
                    ).pack(padx=10, pady=8)
                    
                    expires_time = datetime.fromisoformat(a['expires_at']).strftime('%I:%M %p')
                    tk.Label(
                        details,
                        text=f"⏰ Expires: {expires_time}",
                        font=("Segoe UI", 10),
                        bg=card_color,
                        fg="#2c3e50"
                    ).pack(anchor="w", pady=2)
        
        if not found:
            no_data_frame = tk.Frame(scrollable_frame, bg="#d4edda", relief=tk.SOLID, bd=1)
            no_data_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=50)
            
            tk.Label(
                no_data_frame,
                text="✅ No Pending Payments",
                font=("Segoe UI", 16, "bold"),
                bg="#d4edda",
                fg="#155724"
            ).pack(pady=30)
            
            tk.Label(
                no_data_frame,
                text="All payments are up to date!",
                font=("Segoe UI", 11),
                bg="#d4edda",
                fg="#155724"
            ).pack(pady=(0, 30))
        
        canvas.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(int(-1*(e.delta/120)), "units"))

# Run Application
if __name__ == "__main__":
    root = tk.Tk()
    app = CollegeFineApp(root)
    root.mainloop()
